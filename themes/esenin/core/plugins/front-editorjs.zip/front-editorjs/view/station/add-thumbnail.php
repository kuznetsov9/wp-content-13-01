<?php
defined('ABSPATH') || exit; 
?>

<div class="box upload-image-post">
    <div class="js--image-preview" style="<?php if (has_post_thumbnail($post_edit['id'])): 
        echo 'background-image:url(' . get_the_post_thumbnail_url($post_edit['id']) . '); background-size: cover;'; 
    endif; ?>">

        <?php if (has_post_thumbnail($post_edit['id'])): ?>
            <img src="<?php echo get_the_post_thumbnail_url($post_edit['id']); ?>" alt="thumbnail post" />
            <span class="remove-thumbnail es-icon es-icon-x" title="<?php _e( 'Удалить', 'front-editorjs' ); ?>" data-attach-id="<?php echo get_post_thumbnail_id($post_edit['id']); ?>"></span>
        <?php endif; ?>

        <div class="fred-add-image" <?php if (has_post_thumbnail($post_edit['id'])) echo 'style="display:none;"'; ?>>
            <div class="icon-add-image">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21"></path>
                    <path d="m14 19.5 3-3 3 3"></path>
                    <path d="M17 22v-5.5"></path>
                    <circle cx="9" cy="9" r="2"></circle>
                </svg>
            </div>
            <div class="text-add-image"><?php echo esc_attr__('Загрузите миниатюру', 'front-editorjs'); ?></div>
        </div>
    </div>

    <div class="upload-options">
        <label class="image-upload-label" style="cursor: pointer;">
            <input type="file" class="image-upload" accept="image/*" style="display: none;" /> 
            <input type="hidden" name="thumbnail_id" id="thumbnail_id" 
                value="<?php echo get_post_thumbnail_id($post_edit['id']) ? get_post_thumbnail_id($post_edit['id']) : ''; ?>" />            
        </label>
    </div>
</div>

<script>
    /* Upload Thumbnail */
    document.addEventListener('DOMContentLoaded', function() {
        const fileInput = document.querySelector('.image-upload');
        const imagePreview = document.querySelector('.js--image-preview');

        imagePreview.addEventListener('click', function(event) {
            if (!event.target.classList.contains('remove-thumbnail')) {
                fileInput.click();
            }
        });

        fileInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('file', file);

                fetch('<?php echo admin_url("admin-ajax.php?action=handle_thumb_upload"); ?>', {
                    method: 'POST',
                    body: formData
                }).then(response => response.json()).then(data => {
                    if (data.success) {
                        imagePreview.style.backgroundImage = `url(${data.fileUrl})`;
                        imagePreview.innerHTML = `<img src="${data.fileUrl}" alt="thumbnail post" /><span class="remove-thumbnail es-icon es-icon-x" title="<?php _e( 'Удалить', 'front-editorjs' ); ?>" data-attach-id="${data.attachId}"></span>`;
                        document.getElementById('thumbnail_id').value = data.attachId;
                        document.querySelector('.fred-add-image').style.display = 'none'; 
                    } else {
                        alert(data.message);
                    }
                });
            }
        });

        imagePreview.addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-thumbnail')) {
                const attachId = event.target.dataset.attachId;
                fetch('<?php echo admin_url("admin-ajax.php?action=remove_thumbnail"); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'attachId=' + attachId
                }).then(response => response.json()).then(data => {
                    if (data.success) {
                        imagePreview.style.backgroundImage = 'none';
                        imagePreview.innerHTML = `
                            <div class="fred-add-image">
                                <div class="icon-add-image">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21"></path>
                                        <path d="m14 19.5 3-3 3 3"></path>
                                        <path d="M17 22v-5.5"></path>
                                        <circle cx="9" cy="9" r="2"></circle>
                                    </svg>
                                </div>
                                <div class="text-add-image"><?php echo esc_attr__('Загрузите миниатюру', 'front-editorjs'); ?></div>
                            </div>`;
                        document.getElementById('thumbnail_id').value = '';
                    } else {
                        alert(data.message);
                    }
                });
            }
        });
    });
</script>