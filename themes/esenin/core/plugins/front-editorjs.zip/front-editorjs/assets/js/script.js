window.onload = function() {
	
    // Определяем textarea
    const textToSend = document.getElementById('cont');

    // HTML в JSON
    const jData = stringToBlocks(textToSend.value);

    // JSON в HTML
    const edjsParser = edjsHTML();
	

    let editor = new EditorJS({
        holder: 'editor',
        autofocus: true,
        placeholder: 'Нажмите Tab для выбора инструмента',

        tools: {
			
            header: {
                class: Header,
                inlineToolbar: ['marker', 'link'],
                config: {
                    placeholder: 'Подзаголовок',
                    levels: [2, 3, 4, 5],
                    defaultLevel: 3,
					defaultAlignment: 'left'
                },
            },
			
			paragraph: {
                class: Paragraph,
                inlineToolbar: true,
            },
			
            list: {
                class: List,
                inlineToolbar: true,
				
            },
            quote: {
                class: Quote,
                inlineToolbar: true,
                config: {
                    quotePlaceholder: 'Текст цитаты',
                    captionPlaceholder: 'Подпись',
                },
            },
            marker: {
                class: Marker,
            },
		    underline: Underline,
            delimiter: Delimiter,  

            image: {
              class: ImageTool,
               inlineToolbar: true,
               enableCaption: true,
               captionPlaceholder: 'Enter a caption',    
               config: {
                uploader: {
                  uploadByFile(file) {
                   const formData = new FormData();
                   formData.append('file', file);
                   formData.append('action', 'handle_image_upload');

                   return fetch(`${siteData.url}/wp-admin/admin-ajax.php`, {
                     method: 'POST',
                     body: formData,
                    })
                  .then(response => response.json())
                  .then(result => {
                    if (result.success) {
                        return {
                            success: 1,
                            file: {
                                url: result.file.url,
                            }
                        };
                      } else {
                         throw new Error(result.message);
                      }
                    });
                   },
                  uploadByUrl(url) {
                    const data = {
                       action: 'handle_image_upload_by_url',
                       url: url
                    };

                    return fetch(`${siteData.url}/wp-admin/admin-ajax.php`, {
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json',
                      },
                      body: JSON.stringify(data),
                     })
                     .then(response => response.json())
                     .then(result => {
                       if (result.success) {
                         return {
                            success: 1,
                            file: {
                                url: result.file.url,
                            }
                        };
                    } else {
                        throw new Error(result.message);
                     }
                   });
                 },
               },
             }
           },
			          
///////////////////////////////////

		   linkTool: {
      		class: LinkTool,
      		config: {
        		endpoint: `${siteData.url}/wp-json/edjs/link-info`,
      		    }
    	    },
            embed: {
                class: Embed,
                inlineToolbar: true,
                config: {
                    services: {
                        youtube: true,
                        coub: true,
                        vk: {
                            regex: /https?:\/\/vk\.com\/video(-?\d+)_(\d+)/,
                            embedUrl: '//vk.com/video_ext.php?oid=<%= remote_id %>',
                            html: "<iframe width='100%' height='450' src='<%= embedUrl %>' frameborder='0' allow='autoplay; encrypted-media; fullscreen; picture-in-picture;'></iframe>",
                            id: (groups) => groups[0] + '&id=' + groups[1],
                        },
                        vkvideo: {
                            regex: /https?:\/\/vkvideo\.ru\/video(-?\d+)_(\d+)/,
                            embedUrl: '//vkvideo.ru/video_ext.php?oid=<%= remote_id %>&hd=2',
                            html: "<iframe width='100%' height='450' src='<%= embedUrl %>' frameborder='0' allow='encrypted-media; fullscreen; picture-in-picture; screen-wake-lock;'></iframe>",
                            id: (groups) => groups.join('&id='),
                        },				
						vimeo: true,
						imgur: true,
						codepen: true,
						instagram: true,
						twitter: true,
						pinterest: true,
						facebook: true,
						github: true,					
                    }
                }
            },
		
			telegram: Telegram,
			tiktok: TikTok,
			
			linkButton: {
              class: LinkButton,
               config: {
                 colors: [
                   {
                    name: 'green',
					icon: '<div class="cdx-lbtn_tune-color" style="background-color:#00ad64;"></div>',
                    title: 'Зелёный фон',
                   },
                   {
                    name: 'blue',
					icon: '<div class="cdx-lbtn_tune-color" style="background-color:#275efe;"></div>',
					title: 'Синий фон',
                   }				   
                ]
              },			  
		  },
		  
          alert: {
            class: Alert,
             inlineToolbar: true,
             config: {
             alertTypes: ['primary', 'secondary', 'info', 'success', 'warning', 'danger', 'light', 'dark'],
             defaultType: 'primary',
		     titlePlaceholder: 'Заголовок',
             messagePlaceholder: 'Текст оповещения',		
          },
	  
    },
			
			
        },

        i18n: {
            messages: {
                ui: {
					"popover": {
                            "Filter": "Поиск",
                            "Nothing found": "Ничего не найдено",
							"Convert to": "Преобразовать в",
                    },
                    "blockTunes": {
                        "toggler": {
                            "Click to tune": "Нажмите, чтобы настроить",
                            "or drag to move": "или перетащите"
                        },
                    },
                    "inlineToolbar": {
                        "converter": {
                            "Convert to": "Конвертировать в"
                        }
                    },
                    "toolbar": {
                        "toolbox": {
                            "Add": "Добавить"
                        }
                    }
                },
                toolNames: {
                    "Text": "Текст",
                    "Heading": "Подзаголовок",
                    "List": "Список",
                    "Warning": "Примечание",
                    "Checklist": "Чеклист",
                    "Quote": "Цитата",
                    "Code": "Код",
                    "Delimiter": "Разделитель",
                    "Raw HTML": "HTML-фрагмент",
                    "Table": "Таблица",
                    "Link": "Ссылка",
                    "Marker": "Маркер",
                    "Bold": "Жирный",
                    "Italic": "Курсив",
					"Underline": "Подчёркнутый",
                    "InlineCode": "Моноширинный",
                    "WPImage": "Картинка",
					"Image": "Картинка",
					"Ordered List": "Нумерация",
                    "Unordered List": "Маркеры",
                    "Alert": "Оповещение",					
                },
                tools: {
					"header": {
                       "Header": "Заголовок",
                    },
					"paragraph": {
                       "Enter something": "Введите текст"
                    },
                    "warning": {
                        "Title": "Название",
                        "Message": "Сообщение",
                    },
                     "image": {
                        "Enter a caption": "Описание",
                        "Select an Image": "Загрузите изображение",
                        "With border": "Граница",
                        "Stretch image": "Растянуть",
                        "With background": "Фон",
						"Caption": "Описание",
                    },
                    "link": {
                        "Add a link": "Добавьте ссылку"
                    },
					"linkTool": {
                        "Link": "Вставьте ссылку",
						"Couldn't fetch the link data": "Не удалось получить данные",
                        "Couldn't get this link data, try the other one": "Не удалось получить данные. Попробуйте другую ссылку",
                        "Wrong response format from the server": "Неполадки на сервере",
                    },
                    "stub": {
                        'The block can not be displayed correctly.': 'Блок не может быть отображён'
                    },
					
					"embed": {
                        "Enter a caption": "Подпись",
                    },
					"quote": {
                        "Align Left": "Текст слева",
                        "Align Center": "Текст по центру",
                    },
					"list": {
                        "Unordered": "Обычный",
                        "Ordered": "Нумерованный",
                    },
					"convertTo": {
                         "Convert to": "Преобразовать в",
                    },
					"linkButton": {
                        "Enter a link": "Вставьте ссылку",
						"Enter a caption": "Текст кнопки",
                    },
					"alert": {
                        "Left": "Слева",
                        "Center": "По центру",
                        "Right": "Справа",
						"Primary": "Основной",
						"Secondary": "Вторичный",
						"Info": "Информация",
						"Success": "Успех",
						"Warning": "Предупреждение",
						"Danger": "Опасность",
						"Light": "Светлый",
						"Dark": "Тёмный",
                    },  
					
					
                },
                blockTunes: {
                    "delete": {
                        "Delete": "Удалить блок",
						"Click to delete": "Точно удалить?"
                    },
                    "moveUp": {
                        "Move up": "Переместить вверх"
                    },
                    "moveDown": {
                        "Move down": "Переместить вниз"
                    }
                },
            }
        },

        data: jData,

        onChange: function() {
            editor.save().then((output) => {
                let toHTML = edjsParser.parse(output);
                textToSend.value = "";
                toHTML.forEach(function(item) {
                    textToSend.value += item;
                });
            });
        }
    });

};




