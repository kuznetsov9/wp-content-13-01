<?php 
/**
 * Save post 
 */

if (!defined('ABSPATH')) exit;

function fred_prepare_post_for_db(){
    $post_data = array(   
        'post_modified' => current_time('mysql'), // Используем current_time для правильного таймзона
        'comment_status' => (isset($_POST['comments_disable']) && $_POST['comments_disable'] == '1') ? 'closed' : 'open',
    );

    // Определяем статус поста в зависимости от роли пользователя
    if (current_user_can('administrator') || current_user_can('editor')) {
        $post_data['post_status'] = 'publish'; // Публикуем пост для администраторов и редакторов
        $post_data['post_date'] = current_time('mysql'); // Устанавливаем дату создания поста
    } else {
        $post_data['post_status'] = 'pending'; // Публикуем на модерацию для авторов и подписчиков
        $post_data['post_date'] = current_time('mysql'); // Устанавливаем текущую дату для распоряжений
    }

    // Настройки ID поста
    if(isset($_POST['post_id']) && $_POST['post_id'] > 0){
        $post_data['ID'] = sanitize_key($_POST['post_id']);

        // Устанавливаем время изменения, если пост редактируется
        $post_data['post_modified'] = current_time('mysql');
        // Сохраняем оригинальную дату, если редактирование поста
        $post_data['post_date'] = get_the_date('Y-m-d H:i:s', $_POST['post_id']);
    }

    // Настройка автора поста
    if (isset($_POST['post_author'])){
        $post_data['post_author'] = sanitize_text_field($_POST['post_author']);
    }
    // Настройка заголовка поста
    if (isset($_POST['post_title'])){
        $post_data['post_title'] = sanitize_text_field($_POST['post_title']);
    }
    // Настройка категории поста
    if (isset($_POST['post_category'])){
        $post_data['post_category'] = array(sanitize_key($_POST['post_category']));
    }
    // Настройка содержимого поста
    if (isset($_POST['post_content'])){
        $post_data['post_content'] = wp_kses_post($_POST['post_content']);
    }    
    // Настройка миниатюры поста
    if (isset($_POST['thumbnail_id']) && !empty($_POST['thumbnail_id'])) {
        $post_data['post_thumbnail'] = intval($_POST['thumbnail_id']);
    }    
    // Добавление NSFW
    if (isset($_POST['nsfw_content'])) {
        $post_data['_nsfw_content'] = '1';
    } else {
        $post_data['_nsfw_content'] = '0';
    }
	
	// Добавление скрытого поста
    if (isset($_POST['hidden_post'])) {
        $post_data['_hidden_post'] = '1';
    } else {
        $post_data['_hidden_post'] = '0';
    }

    return $post_data;
}

function fred_save_post(){
    $post_data = fred_prepare_post_for_db();
    $result['id'] = wp_insert_post($post_data, true);

    if (is_wp_error($result['id'])) {
        $result['error'] = $result['id']->get_error_message();
    } else {
        // Если есть миниатюра, устанавливаем ее
        if (isset($post_data['post_thumbnail'])) {
            set_post_thumbnail($result['id'], $post_data['post_thumbnail']);
        }

        // Устанавливаем мета данные
        $comments_disable = isset($_POST['comments_disable']) ? '1' : '0';
        update_post_meta($result['id'], '_comments_disable', $comments_disable);
        update_post_meta($result['id'], '_nsfw_content', isset($_POST['nsfw_content']) ? '1' : '0');
		update_post_meta($result['id'], '_hidden_post', isset($_POST['hidden_post']) ? '1' : '0');

        // Модифицируем ответ для вывода сообщения на фронте
        if (current_user_can('administrator') || current_user_can('editor')) {
            $result['message'] = __('Пост размещён в ленте.', 'front-editorjs'); // Сообщение при публикации
        } else {
            $result['message'] = __('Пост отправлен на модерацию.', 'front-editorjs'); // Сообщение при модерации
        }
    }

    return $result;
}
$fred_post_save_res = fred_save_post();