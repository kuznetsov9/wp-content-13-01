<?php
/**
 * Plugin Name: Front EditorJS
 * Description: Редактор Editor.js для шаблона Esenin
 * Plugin URI: https://devster.ru/
 * Version: 1.0
 * Author: Alexander Khlimankov
 * Author URI: https://t.me/khlimankov
 * Requires at least: 6.8
 * Tested up to: 6.8.1
 * Text Domain: front-editorjs
 * Domain Path: /languages/
 *  
 **/


if ( ! defined( 'ABSPATH' ) ) {	
	exit;
}

if ( ! defined( 'FRONT_EDITORJS_PLUGIN_DIR' ) ) {
	define( 'FRONT_EDITORJS_PLUGIN_DIR',  dirname( __FILE__ )  );
}

if ( ! defined( 'FRONT_EDITORJS_PLUGIN_URL' ) ) {
    define( 'FRONT_EDITORJS_PLUGIN_URL',  plugins_url( '', __FILE__ )  );
}


if( !function_exists( 'fred_register_scripts' ) ) {

    function fred_register_scripts(){
	
        wp_enqueue_script("global-setting", FRONT_EDITORJS_PLUGIN_URL.'/assets/js/vendor/global-setting.js', array());
        wp_enqueue_script("fred-script", FRONT_EDITORJS_PLUGIN_URL.'/assets/js/script.js', array());
		
        wp_localize_script('fred-script', 'siteData', array(
             'url' => site_url() 
        ));
       
        // Plugins Editorjs
        wp_enqueue_script( "fred_underline" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/underline.js");		
        wp_enqueue_script( "fred_delimiter" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/delimiter.js");
        wp_enqueue_script( "fred_embed" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/embed.js");
        wp_enqueue_script( "fred_header" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/header.js");
        wp_enqueue_script( "fred_image" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/image.js");
        wp_enqueue_script( "fred_link" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/link.js");
        wp_enqueue_script( "fred_list" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/list.js");
        wp_enqueue_script( "fred_marker" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/marker.js");
        wp_enqueue_script( "fred_paragraph" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/paragraph.js");
        wp_enqueue_script( "fred_quote" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/quote.js");
        wp_enqueue_script( "fred_button" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/link-button.js");
		wp_enqueue_script( "fred_telegram" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/embed-telegram.js");
		wp_enqueue_script( "fred_tiktok" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/embed-tiktok.js");
		wp_enqueue_script( "fred_alerts" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/alerts.js");
        
        wp_enqueue_script( "fred_editor" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/plugins/editor.js");
		
		// Renders
		wp_enqueue_script( "fred_htmltoeditjs" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/vendor/htmltoeditjs.js");
        wp_enqueue_script( "fred_edjsHTML" , FRONT_EDITORJS_PLUGIN_URL."/assets/js/vendor/edjsHTML.browser.js");		      
 	
	}
}


function front_editorjs_activate() {
    $post_editor_page = array(
        'post_title'    =>  __( "Добавить пост" , 'front-editorjs' ),
        'post_name'     => 'editor',
        'post_content'  => '[fred_post_editor]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
    );
    $post_editor_id = wp_insert_post( $post_editor_page );

    $my_posts_page = array(
        'post_title'    => __( "Мои посты" , 'front-editorjs' ),
        'post_name'     => 'my-posts',
        'post_content'  => '[fred_my_posts]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
    );
    $my_posts_id = wp_insert_post( $my_posts_page );

    update_option( 'front_editorjs_post_editor_page_id', $post_editor_id );
    update_option( 'front_editorjs_my_posts_page_id', $my_posts_id );

    update_option( 'fred_page_shortcode', $post_editor_id );

    $role = get_role( 'author' );
    if ( ! empty( $role ) ) {
        $role->add_cap( 'edit_posts' );
        $role->add_cap( 'create_posts' );
        $role->add_cap( 'publish_posts' ); 
        $role->add_cap( 'edit_published_posts' ); 
    }
}
register_activation_hook( __FILE__, 'front_editorjs_activate' );

function front_editorjs_deactivate() {
    $post_editor_id = get_option( 'front_editorjs_post_editor_page_id' );
    $my_posts_id = get_option( 'front_editorjs_my_posts_page_id' );

    if ( $post_editor_id ) {
        wp_delete_post( $post_editor_id, true );
    }

    if ( $my_posts_id ) {
        wp_delete_post( $my_posts_id, true );
    }

    delete_option( 'front_editorjs_post_editor_page_id' );
    delete_option( 'front_editorjs_my_posts_page_id' );
    delete_option( 'fred_page_shortcode' );

    $role = get_role( 'author' );
    if ( ! empty( $role ) ) {
        $role->remove_cap( 'edit_posts' );
        $role->remove_cap( 'create_posts' );
        $role->remove_cap( 'publish_posts' );
        $role->remove_cap( 'edit_published_posts' );
    }

    global $wpdb;
    $prefix = $wpdb->prefix;

    $wpdb->query( "DELETE FROM {$prefix}postmeta WHERE meta_key LIKE 'fred_%'" );
    $wpdb->query( "DELETE FROM {$prefix}usermeta WHERE meta_key LIKE 'fred_%'" );

}
register_deactivation_hook( __FILE__, 'front_editorjs_deactivate' );

// LOGIC MY POSTS (PAGE)
require (FRONT_EDITORJS_PLUGIN_DIR.'/view/fred_my_posts.php');


// SHORTCODE FOR EDITOR REGISTER
add_shortcode('fred_post_editor', 'fred_post_editor_new_post');

if(!function_exists('fred_post_edit_link')){
    function fred_post_edit_link($link, $post_id, $context) {
        if ( is_admin() ) {
            return $link;
        }

        if ( current_user_can('administrator') ) {
            return $link;
        }

        // Use the correct URL for the editor page
        $editor_page_url = home_url( '/editor/?fred=edit&fred_id=' . $post_id );
        return $editor_page_url;
    }
}

add_filter('edit_post_link','fred_post_edit_link', 10, 3);


function fred_add_edit_links_to_admin_posts_list( $actions, $post ) {
    $edit_link = get_edit_post_link( $post->ID );
    $front_edit_link = home_url( '/editor/?fred=edit&fred_id=' . $post->ID );

    if ($post->post_type == 'post') {
        $actions['edit_front'] = '<a style="color: #00ad64;" target="blank" href="' . esc_url( $front_edit_link ) . '">' . __( 'Изменить (EditorJS)', 'front-editorjs' ) . '</a>';
    }
    return $actions;
}

add_filter( 'post_row_actions', 'fred_add_edit_links_to_admin_posts_list', 10, 2 );
add_filter( 'page_row_actions', 'fred_add_edit_links_to_admin_posts_list', 10, 2 );

///////////////////////////////

if( !function_exists( 'fred_post_editor_new_post' ) ) {
    function fred_post_editor_new_post(){
		wp_enqueue_style('fred-editor-style', FRONT_EDITORJS_PLUGIN_URL.'/assets/css/editor.css');
        wp_enqueue_style('fred-style', FRONT_EDITORJS_PLUGIN_URL.'/assets/css/style.css');
		
        wp_enqueue_media ();
        fred_register_scripts();

        if(isset($_POST['fred_post_save'])&&$_POST['fred_post_save']=='post_save'){
            if(wp_verify_nonce($_POST['_wpnonce'])){
                require (FRONT_EDITORJS_PLUGIN_DIR.'/inc/fred_post_save.php');
            }
        }

        if ( is_user_logged_in() ) {
            $user = wp_get_current_user();
            $allowed_roles = array( 'administrator', 'editor', 'author' );
            if ( array_intersect( $allowed_roles, $user->roles ) ) {
                require (FRONT_EDITORJS_PLUGIN_DIR.'/view/fred_new_post_editor.php');
            } else {
                echo '<p>'.__( "Вам не разрешено создавать посты." , 'front-editorjs' ).'</p>';
            }
        } else {
            echo '<p>'.__( "Для добавления постов авторизуйтесь на сайте." , 'front-editorjs' ).'</p>';
        }
    }
}

add_action( 'plugins_loaded', 'fred_language_files_init' );
function fred_language_files_init(){
	load_plugin_textdomain( 'front-editorjs', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}


///////////////////////

function allow_iframe_in_wordpress() {
    global $allowedposttags;
    $allowedposttags['iframe'] = array(
        'src' => array(),
        'height' => array(),
        'width' => array(),
        'frameborder' => array(),
        'scrolling' => array(),
        'allowfullscreen' => array(),
        'title' => array(),
    );
}
add_action('init', 'allow_iframe_in_wordpress');

///////////////////

add_action('rest_api_init', function () {
    register_rest_route('edjs', 'link-info', array(
        'methods' => 'GET',
        'callback' => 'get_link_info',
    ));
});

function get_link_info($request) {
    $url = esc_url($request->get_param('url'));
    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        return new WP_Error('link_error', 'Ошибка получения ссылки', array('status' => 500));
    }

    $body = wp_remote_retrieve_body($response);
    $meta = extract_meta_data($body);

    return rest_ensure_response(array(
        'success' => 1,
        'link' => $url,
        'meta' => $meta
    ));
}

function extract_meta_data($html) {
    $meta = array();

    if (preg_match('/<title>(.*?)<\/title>/', $html, $matches)) {
        $meta['title'] = $matches[1];
    }

    if (preg_match('/<meta name="description" content="(.*?)"/', $html, $matches)) {
        $meta['description'] = $matches[1];
    }

    if (preg_match('/<meta property="og:image" content="(.*?)"/', $html, $matches)) {
        $meta['image'] = array('url' => $matches[1]);
    }

    return $meta;
}

/////////////////////////////

// upload_image
function handle_image_upload() {
    if (!empty($_FILES['file'])) {
        $uploaded_file = $_FILES['file'];
        $upload_dir = wp_upload_dir();
        $upload_path = $upload_dir['path'];
        $filename = basename($uploaded_file['name']);
        $target_file = $upload_path . '/' . $filename;

        if (move_uploaded_file($uploaded_file['tmp_name'], $target_file)) {
            $attachment = array(
                'guid' => $upload_dir['url'] . '/' . basename($target_file), 
                'post_mime_type' => $uploaded_file['type'],
                'post_title' => sanitize_file_name($filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );

            $attach_id = wp_insert_attachment($attachment, $target_file);
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata($attach_id, $target_file);
            wp_update_attachment_metadata($attach_id, $attach_data);

            $response = array(
                'success' => true,
                'file' => array(
                    'url' => $upload_dir['url'] . '/' . basename($target_file)
                )
            );
        } else {
            $response = array('success' => false, 'message' => 'Ошибка загрузки файла.');
        }
    } else {
        $response = array('success' => false, 'message' => 'Файл не найден.');
    }

    echo json_encode($response);
    wp_die();
}

add_action('wp_ajax_handle_image_upload', 'handle_image_upload');


function handle_image_upload_by_url() {
    if (!empty($_POST['url'])) {
        $url = esc_url_raw($_POST['url']);

        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            echo json_encode(array(
                'success' => false,
                'message' => 'Ошибка при получении изображения по URL.'
            ));
            wp_die();
        }

        $image_data = wp_remote_retrieve_body($response);

        $upload_dir = wp_upload_dir();
        $temp_file = tempnam($upload_dir['path'], 'temp_image_');
        file_put_contents($temp_file, $image_data);

        $filename = basename($url);
        $target_file = $upload_dir['path'] . '/' . $filename;

        if (rename($temp_file, $target_file)) {
            $attachment = array(
                'guid' => $upload_dir['url'] . '/' . basename($target_file), 
                'post_mime_type' => 'image/jpeg', 
                'post_title' => sanitize_file_name($filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );

            $attach_id = wp_insert_attachment($attachment, $target_file);
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata($attach_id, $target_file);
            wp_update_attachment_metadata($attach_id, $attach_data);

            $response = array(
                'success' => true,
                'file' => array(
                    'url' => $upload_dir['url'] . '/' . basename($target_file)
                )
            );
        } else {
            $response = array('success' => false, 'message' => 'Ошибка при сохранении файла.');
        }
    } else {
        $response = array('success' => false, 'message' => 'URL не найден.');
    }

    echo json_encode($response);
    wp_die();
}

add_action('wp_ajax_handle_image_upload_by_url', 'handle_image_upload_by_url');


/////////////////

// upload_thumb
function handle_thumb_upload() {
    if (!empty($_FILES['file'])) {
        $uploaded_file = $_FILES['file'];
        $upload_dir = wp_upload_dir();

        if ($uploaded_file['error'] === 0) {
            $filename = sanitize_file_name($uploaded_file['name']);
            $target_file = $upload_dir['path'] . '/' . $filename;

            if (move_uploaded_file($uploaded_file['tmp_name'], $target_file)) {
                $attachment = array(
                    'guid' => $upload_dir['url'] . '/' . basename($target_file), 
                    'post_mime_type' => $uploaded_file['type'],
                    'post_title' => sanitize_file_name($filename),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );

                $attach_id = wp_insert_attachment($attachment, $target_file);
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                $attach_data = wp_generate_attachment_metadata($attach_id, $target_file);
                wp_update_attachment_metadata($attach_id, $attach_data);

                echo json_encode(array('success' => true, 'fileUrl' => $upload_dir['url'] . '/' . basename($target_file), 'attachId' => $attach_id));
            } else {
                echo json_encode(array('success' => false, 'message' => 'Ошибка перемещения файла.'));
            }
        } else {
            echo json_encode(array('success' => false, 'message' => 'Ошибка загрузки файла.'));
        }
    }
    wp_die();
}

function remove_thumbnail() {
    $attach_id = intval($_POST['attachId']);

    if (wp_delete_attachment($attach_id, true)) {
        echo json_encode(array('success' => true));
    } else {
        echo json_encode(array('success' => false, 'message' => 'Ошибка удаления.'));
    }

    wp_die();
}

add_action('wp_ajax_handle_thumb_upload', 'handle_thumb_upload');
add_action('wp_ajax_remove_thumbnail', 'remove_thumbnail');


// Block Hidden Content

add_filter('the_content', 'custom_display_hidden_content');

function custom_display_hidden_content($content) {
    $current_user = wp_get_current_user();
    $post_id = get_the_ID();
    $is_hidden = get_post_meta($post_id, '_hidden_post', true);

    if ($is_hidden && !in_array('administrator', $current_user->roles) && !in_array('editor', $current_user->roles)) {
        $subscribed = false;

        global $wpdb;
        $table_name = $wpdb->prefix . 'user_subscriptions';

        $subscriptions = $wpdb->get_col($wpdb->prepare("SELECT subscriber_id FROM $table_name WHERE user_id = %d", get_post_field('post_author', $post_id)));

        if (in_array($current_user->ID, $subscriptions)) {
            $subscribed = true;
        }

    if (!$current_user->ID) {
        $paragraphs = explode("\n", $content);
        if (count($paragraphs) > 2) {
            $visible_content = implode("\n", array_slice($paragraphs, 0, 2));
            return $visible_content . '<div class="esn-hidden-block">' .
                   '<div class="esn-hidden-block-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="512" height="512"><g><path d="M405.333,179.712v-30.379C405.333,66.859,338.475,0,256,0S106.667,66.859,106.667,149.333v30.379   c-38.826,16.945-63.944,55.259-64,97.621v128C42.737,464.214,90.452,511.93,149.333,512h213.333   c58.881-0.07,106.596-47.786,106.667-106.667v-128C469.278,234.971,444.159,196.657,405.333,179.712z M277.333,362.667   c0,11.782-9.551,21.333-21.333,21.333c-11.782,0-21.333-9.551-21.333-21.333V320c0-11.782,9.551-21.333,21.333-21.333   c11.782,0,21.333,9.551,21.333,21.333V362.667z M362.667,170.667H149.333v-21.333c0-58.91,47.756-106.667,106.667-106.667   s106.667,47.756,106.667,106.667V170.667z"/></g></svg></div>' .
                   '<div class="esn-hidden-block-title">' . __('Скрытый контент', 'front-editorjs') . '</div>' .
                   '<div class="esn-hidden-block-text">' . sprintf(__('Для продолжения <a href="%s">авторизуйтесь</a> на сайте.', 'front-editorjs'), '#login') . '</div>' .
                   '</div>';
        }
    }

    if (!$subscribed) {
        $paragraphs = explode("\n", $content);
        if (count($paragraphs) > 2) {
            $visible_content = implode("\n", array_slice($paragraphs, 0, 2));
            return $visible_content . '<div class="esn-hidden-block">' .
                   '<div class="esn-hidden-block-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="512" height="512"><g><path d="M405.333,179.712v-30.379C405.333,66.859,338.475,0,256,0S106.667,66.859,106.667,149.333v30.379   c-38.826,16.945-63.944,55.259-64,97.621v128C42.737,464.214,90.452,511.93,149.333,512h213.333   c58.881-0.07,106.596-47.786,106.667-106.667v-128C469.278,234.971,444.159,196.657,405.333,179.712z M277.333,362.667   c0,11.782-9.551,21.333-21.333,21.333c-11.782,0-21.333-9.551-21.333-21.333V320c0-11.782,9.551-21.333,21.333-21.333   c11.782,0,21.333,9.551,21.333,21.333V362.667z M362.667,170.667H149.333v-21.333c0-58.91,47.756-106.667,106.667-106.667   s106.667,47.756,106.667,106.667V170.667z"/></g></svg></div>' .
                   '<div class="esn-hidden-block-title">' . __('Скрытый контент', 'front-editorjs') . '</div>' .
                   '<div class="esn-hidden-block-text">' . sprintf(__('Для продолжения подпишитесь на <a href="%s">автора</a> поста.', 'front-editorjs'), get_author_posts_url(get_post_field('post_author', $post_id))) . '</div>' .
                   '</div>';
        }
      }
    }
	
    return $content;
}